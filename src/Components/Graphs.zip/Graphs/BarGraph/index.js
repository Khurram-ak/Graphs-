import React from 'react';
import { Bar } from 'react-chartjs-2';

const data = {
    labels: ['January', 'Febuarary', 'March', 'April', 'May', 'June', "July", "August", "September", "October", "November", "December"],
    datasets: [
        {
            label: 'Number Of Employes',
            data: [12, 19, 13, 9, 2, 8, 6, 10, 5, 12, 14, 9],
            backgroundColor: 'rgb(255, 99, 132)',
        },
        {
            label: 'Number Of Applicants',
            data: [2, 3, 20, 5, 12, 4, 7, 11, 8, 17, 11, 7],
            backgroundColor: 'rgb(54, 162, 235)',
        },

    ],
};

const options = {
    scales: {
        yAxes: [
            {
                ticks: {
                    beginAtZero: true,
                },
            },
        ],
    },
};

const GroupedBar = () => (
    <>
        <Bar data={data} options={options} />
    </>
);

export default GroupedBar;