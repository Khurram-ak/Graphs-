import "./index.css"
import { Doughnut } from 'react-chartjs-2';



export default function DoughnutChart() {
    const data = {
        labels: ['Karachi', 'Lahore','Islamabad',"Quetta", 'Rawalpindi'],
        datasets: [
            {
                label: '# of Votes',
                data: [342, 231, 121, 120,111],
                backgroundColor: [
                    '#dd6969',
                    '#e6d251',
                    '#8cb677',
                    '#58b4bb',
                    '#314e6d'
                ],
                borderColor: [
                    '#dd6969',
                    '#e6d251',
                    '#8cb677',
                    '#58b4bb',
                    '#314e6d'
                ],
                borderWidth: 3,
            },
        ],

    };


    return (
        <div className="centerDiv2">
            <Doughnut
                className="graph"
                responsive
                data={data}
                options={{
                    plugins: {
                        legend: {
                            labels: {
                                font: {
                                    size: 12,
                                }
                            }
                        }
                    },
                    maintainAspectRatio: true
                }}
            />
        </div>
    )
}

