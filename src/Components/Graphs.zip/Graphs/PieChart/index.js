import React from 'react';
import { Pie } from 'react-chartjs-2';
import "./index.css"

const data = {
    labels: ['Karachi', 'Lahore', 'Islamabad', 'Quetta', 'Rawalpindi'],
    datasets: [
        {
            label: '# of Votes',
            data: [8, 12, 4, 5, 2],
            backgroundColor: [
                '#dd6969',
                '#e6d251',
                '#8cb677',
                '#58b4bb',
                '#314e6d',
            ],
            borderColor: [
                '#dd6969',
                '#e6d251',
                '#8cb677',
                '#58b4bb',
                '#314e6d',
            ],
            borderWidth: 1,
        },
    ],
};

const PieChart = () => {

    return <>

        <Pie
            className="pieChart"
            data={data}
            options={{
                plugins: {
                    legend: {
                        labels: {
                            font: {
                                size: 22,
                            }
                        }
                    }
                }
            }
            }
        />
    </>
}

export default PieChart;